import json
import os
import time
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

import xbmc
import xbmcgui
import xbmcvfs

from .common import *

class Downloader:

    def __init__(self):
        self.stop = False
        self.dp = None
        self.path = None

    def download_videos_from_urls(self, urllist):
        self.dp = xbmcgui.DialogProgress()
        self.dp.create(translate(32000), translate(32012))

        for url in urllist:
            if not self.stop:
                video_file = url.split("/")[-1]
                local_video_path = os.path.join(addon.getSetting("download-folder"), video_file)

                # If the file exists at the download location:
                if xbmcvfs.exists(local_video_path):
                    xbmc.log(f"File {video_file} already exists, skip download", level=xbmc.LOGDEBUG)
                    
                    xbmcgui.Dialog().ok(
                        translate(32000),
                        f"{video_file} {translate(32038)}"
                    )
                    
                    continue

                try:
                    self.download(local_video_path, url, video_file)
                except (URLError, HTTPError) as e:
                    xbmc.log("Error downloading {}: {}. Skipping to next file.".format(url, str(e)), level=xbmc.LOGWARNING)
                    # Display message in progress dialog that file is being skipped
                    self.dp.update(0, "Failed to download {}. Skipping...".format(video_file))
                    xbmc.sleep(1500)  # Brief pause to show the message
                    continue
            else:
                break

    def download(self, path, url, name):
        xbmc.log("Downloading {}".format(url), level=xbmc.LOGDEBUG)
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)

        self.dp.update(0, name)
        self.path = xbmcvfs.translatePath(path)
        xbmc.sleep(500)
        start_time = time.time()

        u = urlopen(url)
        meta = u.info()
        meta_func = meta.getheaders if hasattr(meta, "getheaders") else meta.get_all
        meta_length = meta_func("Content-Length")
        file_size = None
        block_sz = 8192
        if meta_length:
            file_size = int(meta_length[0])

        file_size_dl = 0
        with xbmcvfs.File(self.path, 'wb') as f:
            numblocks = 0
            while not self.stop:
                buffer = u.read(block_sz)
                if not buffer:
                    break

                f.write(buffer)
                file_size_dl += len(buffer)
                numblocks += 1
                self.dialogdown(name, numblocks, block_sz, file_size, self.dp, start_time)

    def dialogdown(self, name, numblocks, blocksize, filesize, dp, start_time):
        try:
            percent = int(min(numblocks * blocksize * 100 / filesize, 100))
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
            kbps_speed = numblocks * blocksize / (time.time() - start_time)
            if kbps_speed > 0:
                eta = (filesize - numblocks * blocksize) / kbps_speed
            else:
                eta = 0
            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = '%.02f MB %s %.02f MB' % (currently_downloaded, translate(32008), total)
            e = ' (%.0f Kb/s) ' % kbps_speed
            tempo = translate(32009) + ' %02d:%02d' % divmod(eta, 60)
            dp.update(percent, f"{name} - {mbs}{e}\n{tempo}")
        except Exception:
            percent = 100
            dp.update(percent)

        if dp.iscanceled():
            self.stop = True
            dp.close()
            try:
                xbmcvfs.delete(self.path)
            except Exception:
                xbmc.log(msg='[Matrix Screensavers] Could not remove file', level=xbmc.LOGERROR)
            xbmc.log(msg='[Matrix Screensavers] Download canceled', level=xbmc.LOGDEBUG)
