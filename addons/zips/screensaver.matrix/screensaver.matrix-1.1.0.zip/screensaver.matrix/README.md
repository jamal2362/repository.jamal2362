# screensaver.matrix

## Matrix screensavers for Kodi 21 (Omega)
This addon adds the Matrix screensavers to Kodi Entertainment Center.

## Plugin Features
- JSON-based video playlist fetching and playback
- 1080p 60fps
- Filtering of videos
- Online or offline mode (5.85GB)
  - Download location by scene or all at once
  - Full offline mode to prevent all network calls, using only local videos and JSON
  - Validation to prevent unnecessary re-downloading of cached videos
- Display Power Management Signaling (DPMS) configurable
  - When the display is supposed to go to sleep, pause/stop the Matrix video and turn the display off or put it into standby via HDMI CEC

# Screenshots
![Screenshot1](https://raw.githubusercontent.com/jamal2362/screensaver.matrix/main/resources/screenshots/screenshot-01.jpg)

![Screenshot2](https://raw.githubusercontent.com/jamal2362/screensaver.matrix/main/resources/screenshots/screenshot-02.jpg)

![Screenshot3](https://raw.githubusercontent.com/jamal2362/screensaver.matrix/main/resources/screenshots/screenshot-03.jpg)

![Screenshot4](https://raw.githubusercontent.com/jamal2362/screensaver.matrix/main/resources/screenshots/screenshot-04.jpg)
