import sys

from resources.lib import matrix

matrix.run(len(sys.argv) > 1)
