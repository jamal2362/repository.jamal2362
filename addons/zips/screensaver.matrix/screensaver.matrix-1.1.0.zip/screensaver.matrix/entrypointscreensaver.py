from resources.lib import screensaver

screensaver.run()
